import tkinter as tk
import bs4, requests,datetime

HEIGHT = 550
WIDTH = 650
def get_weather(city):
    miasto = city
    url = 'https://pogoda.wprost.pl/prognoza-pogody/' + str(city)
    print(url)
    d = datetime.datetime.today()
    while True:
        try:
            res = requests.get(url)
            res.raise_for_status()
            soup = bs4.BeautifulSoup(res.text,"html.parser")
            miasto1 = soup.find("strong", class_="city-name").text
            dzien = soup.find("span", class_="weather-day").text
            data = soup.find("span", class_="weather-date").text
            temperatura = soup.find("dd", class_="weather-temp").text
            cisnienie = soup.find("dd", class_="weather-pressure").text
            wiatr = soup.find("dd", class_="weather-wind").text
            wilgotnosc = soup.find("dd", class_="weather-humidity").text
            zachmurzenie = soup.find("dd", class_="weather-clouds").text

            if miasto1[0].lower() != city[0]:
                label['text'] = ('Podano zły typ danych.' + '\n' + 
                'Pamiętaj aby wpisywać miasto z małej litery bez polskich znaków.' + '\n'
                + 'Dane pochodzą ze strony https://pogoda.wprost.pl/prognoza-pogody/' + '\n'
                + 'Jeśli strona ta nie zawiera podanego miasta aplikacja nie będzie działać')
                break
            else:
                label['text'] = ('pogoda na dzien ' + data + ' ' + dzien + ' w mieście ' + miasto1 + '\n' 
                + 'dokładna data wraz z godziną ' + str(d) + '\n' + 'temeratura: ' + temperatura + '\n' + 
                'cisnienie: ' + cisnienie + '\n' +
                'wiatr: ' + wiatr + '\n' +
                'wilgotnosc: ' + wilgotnosc + '\n' +
                'zachmurzenie: ' + zachmurzenie )
        
                break
        except:
            label['text'] = 'Podano zły typ danych' + '\n' +  'lub nie znaleziono podanego miasta'
            break

root = tk.Tk()

canvas = tk.Canvas(root,height=HEIGHT,width=WIDTH)
canvas.pack()

background_image = tk.PhotoImage(file='pexels-pok-rie-7837732.png')
background_label = tk.Label(root, image=background_image)
background_label.place(relwidth=1,relheight=1)

frame = tk.Frame(root,bg='#008000')
frame.place(relx=0.5, rely=0.1, relwidth=0.75, relheight=0.1,anchor='n')

entry = tk.Entry(frame, font='40')
entry.place(relwidth=0.65,relheight=1)

button = tk.Button(frame,text='Sprawdź pogodę',font=40,command=lambda: get_weather(entry.get()))
button.place(relx=0.7,relheight=1,relwidth=0.3)

lower_frame = tk.Frame(root,bg='#008000',bd=10)
lower_frame.place(relx=0.5,rely=0.25,relwidth=0.75,relheight=0.6,anchor='n')

label = tk.Label(lower_frame)
label.place(relwidth=1,relheight=1)


root.mainloop()